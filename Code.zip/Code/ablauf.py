# ################################################################
# ############## Konfiguriere hier dein Experiment ###############
# ################################################################

# Moegliche Aktionen (nicht aendern!)
AEROSOL = AG = "aerosol"                            # Nur Aerosolgenerator
CLEAN = RLR = "clean"                               # Nur Raumluftreiniger
CLEAN_AC = RLR_AC = "clean+ac"                      # Raumluftreiniger + Klimaanlage
PAUSE = P = "pause"                                 # Gar nichts tun, nur messen
VENTILATOR = FAN = "ventilator"                     # Nur Ventilator
AEROSOL_VENTILATOR = AG_FAN = "aerosol+ventilator"  # Aerosolgenerator + Ventilator


# Achte darauf, dass hier alle Werte (inklusive ID!) passen
experiment = {

    "id": "DBS86",  				                    # Versuch Nummer/ID

    "pre": [(20, CLEAN), (2, PAUSE)],               # wird einmalig vor dem Versuch ausgefuehrt

    "repeats": 26,				                    # wie haeufig der in "protocol" beschriebene Versuchsablauf wiederholt wird

    "protocol": [
        (10, AG, "during"),
        (20, PAUSE, "during"),
        (20, CLEAN, "inbetween"),
        (2, PAUSE, "inbetween"),
    ],

    "post": []                                      # wird einmalig am Ende des Versuchs ausgefuehrt
}
