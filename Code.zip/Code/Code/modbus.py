from typing_extensions import Final
from pymodbus.client.sync import ModbusTcpClient
import struct
from time import time
from datetime import datetime


class Modbus:
    '''Connect to a Grimm 11D with Modbus TCP and read data'''

    # The 11D has 31 different size channels
    MAX_CHANNEL_NR: Final[int] = 31

    def __init__(self, ip: str):
        # set up the modbus connection to an 11D
        self.client = ModbusTcpClient(ip)

    def __del__(self):
        self.client.close()

    # Methods for reading raw data ----------------------------------

    def _get_unsigned(self, address: int) -> int:
        '''Read an unsigned modbus register'''
        result = self.client.read_holding_registers(address=address, count=2, unit=0x1)
        high, low = result.registers
        return (high << 16) + low

    def _get_float(self, address: int) -> float:
        '''Read a float modbus register'''
        unsigned = self._get_unsigned(address) 
        byte_val = unsigned.to_bytes(4, 'little')
        float_val = struct.unpack('f', byte_val)
        return float_val[0]

    # Methods for retrieving data from the device -----------------------

    def get_betriebsstatus(self) -> int: 
        '''0 = Standby, 1 = Selbsttest, 2 = Messbetrieb'''
        return self._get_unsigned(1002)

    def get_total_count(self) -> int:
        '''Return the total number of particels per Liter'''
        return self._get_unsigned(14)

    def get_kanal_count(self, kanal_nr: int):
        '''Channel number must be between 1 and 31'''
        register = 30 + 2 * (kanal_nr - 1)

        kumulativ = self._get_unsigned(register)
        ein_kanal_drueber = self._get_unsigned(register + 2)
        
        if (kanal_nr < self.MAX_CHANNEL_NR):
            return kumulativ - ein_kanal_drueber
        else:
            return kumulativ

    def get_kanal_schwelle(self, kanal_nr: int):
        register = 204 + 2 * (kanal_nr - 1)
        return self._get_float(register)

    def get_PM10(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(2)

    def get_PM4(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(4)

    def get_PM2_5(self):
        '''PM2.5; Unit: microgram per cubic meter'''
        return self._get_float(6)

    def get_PM1(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(8)

    def get_PMcoarse(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(10)

    def get_inhalable(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(16)

    def get_thoracic(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(18)

    def get_respirable(self):
        '''Unit: microgram per cubic meter'''
        return self._get_float(20)

    def get_external_temperature(self):
        '''Unit: degrees Celsius; Temperature/Humidity probe must be connected'''
        return self._get_float(350)

    def get_external_humidity(self):
        '''Unit: %; Temmperature/Humidity probe must be connected'''
        return self._get_float(352)

    def get_air_pressure(self):
        '''Unit: hectoPascal'''
        return self._get_float(356)

    def get_wind_speed(self) -> float:
        '''Unit: m/s; Windspeed probe must be connected'''
        return self._get_float(354)

    def get_error_code(self):
        return self._get_unsigned(504)

    def get_interval(self):
        '''Unit: microgram per cubic meter'''
        return self._get_unsigned(1000)

    def get_motor_current(self):
        '''Unit: mA'''
        return self._get_unsigned(424)

    def get_header_row(self):
        '''Get the header row for the csv file to store the data'''
        header = ["time", "epoch", "total_count", "PM10", "PM4", "PM2.5",
                  "PM1", "PM_coarse", "inhalable", "thoracic", "respirable"]
        channel_sizes = ["{:.2f}".format(self.get_kanal_schwelle(nr))
                         for nr in list(range(1, 32))]
        header += channel_sizes
        header += ["external_temperature", "external_humidity", "air_pressure",
                   "wind_speed", "motor_current", "error_code"]
        return header

    def get_data_row(self):
        '''Get all the data the device outputs in one list which fits to the header
        returned by get_header_row()'''
        data = [
            str(datetime.now()), time(),
            self.get_total_count(), self.get_PM10(), self.get_PM4(), 
            self.get_PM2_5(), self.get_PM1(), self.get_PMcoarse(),
            self.get_inhalable(), self.get_thoracic(), self.get_respirable()
        ]
        data += [self.get_kanal_count(nr) for nr in list(range(1, 32))]
        data += [
            self.get_external_temperature(), self.get_external_humidity(),
            self.get_air_pressure(), self.get_wind_speed(), 
            self.get_motor_current(), self.get_error_code()
        ]
        return data

    def get_data_row_string(self):
        '''Get all the data from get_data_row() but as strings'''
        return [str(datum) for datum in self.get_data_row()]