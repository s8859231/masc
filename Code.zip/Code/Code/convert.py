# HIER WERTE ANPASSEN
######################################
STD_DEVS = 3 # Filtere ausreißer bei jeder Messreihe, die mehr als soviele Standardabwichungen von den anderen Runden zum selben Zeitpunkt abweichen
#########################################

import sys
import pandas as pd
import numpy as np
from sklearn import metrics
import os

path = sys.argv[1]
PARAM = sys.argv[2] # welche Spalte zur Auswertung genommen werden soll


# datei einlesen
base_path, file_name = os.path.split(path)
stat_path = base_path + "/Auswertung/" # Stats/"
print(stat_path)
try:
    os.mkdir(stat_path)
except Exception as e:
    print(e)

raw_df = pd.read_csv(path)
raw_df.name = path

def clean_df(df:pd.DataFrame) -> pd.DataFrame:

    def filter_phase_and_cols(df: pd.DataFrame) -> pd.DataFrame:

        # Filter out certain rounds
        df_copy = df[df.stage_name == "during"]

        # Drop text columns, which hinder computation
        df_copy.drop(["time", "stage_name", "activity_name"], axis=1, inplace=True)

        # Calculate total particle volume in a certaint size range
        # rs = np.array([float(x) for x in df_copy.iloc[:, range(11, 29)].columns.values])

        # vols = 4/3 * rs*rs*rs * math.pi
        # counts = df.iloc[:, range(11, 29)]

        # df_copy["pm_vol"] = (counts * vols).sum(axis=1)
        

        df_copy.name = df.name
        return df_copy
    
    def trim_to_same_length(df: pd.DataFrame) -> pd.DataFrame:
        '''Alle frames auf die selbe länge kürzen'''
        lowest_max_current_index = df.groupby(["round_nr"]).max().min()["current_index"]
        ret = df[df.current_index <= lowest_max_current_index]
        ret.name = df.name
        return ret

    def filter_outliers(df: pd.DataFrame):
        rdf = df.groupby(["current_index"]).apply(lambda g: g[(g[PARAM] < g[PARAM].mean() + STD_DEVS * g[PARAM].std())
                                                            & (g[PARAM] > g[PARAM].mean() - STD_DEVS * g[PARAM].std())]).reset_index(drop=True)
        rdf.name = df.name
        return rdf
        return filter_phase_and_cols(filter_outliers(trim_to_same_length(df)))

    return filter_outliers(trim_to_same_length(filter_phase_and_cols(df)))

df = clean_df(raw_df)

# nur die wichtigen spalten aufheben
df = df[["round_nr", "current_index", PARAM]]
df["time_s"] = df.current_index * 6

# Mittelwerte für die Runden
round_nr_means = df.groupby(["round_nr"]).mean()
#round_nr_means["AUC"] = df.groupby(["round_nr"]).apply(lambda g: metrics.auc(g["time_s"], g[PARAM]))
round_nr_means.name = PARAM + "_mean"
#round_nr_means.rename(index=str, columns={"PM2.5", "PM2.5_mean"})
round_nr_means.drop(["current_index", "time_s"], axis=1, inplace=True)
round_nr_means.to_csv(stat_path + file_name + "_" + PARAM + "_mean.csv")

# Mittelwerte zu jedem zeitpunkt
ci_means = df.groupby(["current_index"]).mean()
ci_means["time_s"] = ci_means.index * 6
ci_means["std"] = df.groupby(["current_index"]).std()[PARAM]
ci_means["q0.05"] = df.groupby(["current_index"]).quantile(0.05)[PARAM]
ci_means["q0.25"] = df.groupby(["current_index"]).quantile(0.25)[PARAM]
ci_means["q0.75"] = df.groupby(["current_index"]).quantile(0.75)[PARAM]
ci_means["q0.95"] = df.groupby(["current_index"]).quantile(0.95)[PARAM]
ci_means.drop("round_nr", axis=1, inplace=True)
ci_means.to_csv(stat_path + file_name + "_" + PARAM + "timeseries.csv") 
