from time import sleep
from datetime import datetime
from picamera import PiCamera
import os
import sys
import cv2 as cv
import numpy as np
import imageio as imageio
import matplotlib.pyplot as plt
import os


camera = PiCamera()
camera.iso = 800
camera.shutter_speed = int(0.1 * 1000000)
camera.resolution = (1280, 720)  # max=(4056, 3040)
camera.start_preview()

sleep(1)  # Camera warm-up time

img_dir = '/home/pi/Aerosol/Images/' + str(datetime.now()) + "/"
savedir = img_dir + "original/"
os.makedirs(savedir)
os.makedirs(img_dir + "sub/")

i = 1
MAX_PICTURES = int(sys.argv[1])

for filename in camera.capture_continuous(savedir + 'img{counter:03d}.jpg'):
    if i > MAX_PICTURES:
        break
    print('Captured %s' % filename)
    i += 1
    #sleep(0.5) # wait 5 minutes


camera.close()

############# Postprocessing


first_image = cv.imread(savedir + "img001.jpg")  # gets subtracted from all other images
images = []  # storage for gif making
images_sub = []
green_pixels = []

ed = cv.Canny(image=first_image, threshold1=300, threshold2=500)
edges = np.zeros((first_image.shape[0], first_image.shape[1], 3))
edges[:,:,0] = ed
edges[:,:,1] = ed
edges[:,:,2] = ed
#cv.imshow('Canny Edge Detection', edges)
# cv.waitKey(0)


for filename in sorted(os.listdir(savedir)):
    if ".jpg" in filename:
        print(filename)
        image = cv.imread(savedir + filename)
        sub_img = cv.absdiff(image, first_image)

        sub_img[:, :, 2] = np.zeros([sub_img.shape[0], sub_img.shape[1]])
        sub_img[:, :, 0] = np.zeros([sub_img.shape[0], sub_img.shape[1]])

        cv.imwrite(img_dir + "sub/" + filename, sub_img)

        images.append(imageio.imread(savedir + filename))
        images_sub.append(np.maximum(sub_img, edges))
        green_pixels.append(np.sum(sub_img[:, :, 1]))

imageio.mimsave(img_dir + 'movie.mp4', images, fps=2)
imageio.mimsave(img_dir + 'movie_sub.mp4', images_sub, fps=2)
plt.plot(green_pixels)
plt.savefig(img_dir + "plot.png")