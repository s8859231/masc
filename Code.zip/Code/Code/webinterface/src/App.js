import logo from './logo.svg';
import './App.css';

function App() {

  
    function rlrOn() {
        fetch('http://192.168.1.74:4000/clean1')
    }

    function rlrOff() {
        fetch('http://192.168.1.74:4000/clean0')
    }
    
    function aerosolOn() {
        fetch('http://192.168.1.74:4000/aerosol1')
    }

    function aerosolOff() {
        fetch('http://192.168.1.74:4000/aerosol0')
    }

    function expStart() {
        fetch('http://192.168.1.74:4000/experimentStart')
    }

    function expKill() {
        fetch('http://192.168.1.74:4000/experimentKill')
    }

    function test() {
        fetch('http://192.168.1.74:4000/test')
    }

    return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        

        <table>
            <tr>
                <td>
                    <h4>Raumluftreiniger</h4>
                    <button onClick={rlrOn}>On</button>
                    <button onClick={rlrOff}>Off</button>
                </td>

                <td>
                    <h4>Aerosol</h4>
                    <button onClick={aerosolOn}>On</button>
                    <button onClick={aerosolOff}>Off</button>
                </td>

                <td>
                    <h4>Experiment</h4>
                    <button onClick={expStart}>Start</button>
                    <button onClick={expKill}>Kill</button>
                </td>                
            </tr>
                <td>
                    <h4>Test Equip</h4>
                    <button onClick={test}>Test</button>
                </td>  
            <tr>
            </tr>
        </table>


      </header>
    </div>
    );
}




export default App;
