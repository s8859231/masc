import plotly.graph_objects as go # or plotly.express as px
import plotly.express as px
import pandas as pd
import dash
from dash import dcc
from dash import html
import os
import json
from datetime import datetime, timedelta
from setproctitle import setproctitle

setproctitle("UsageDashboard")


fig = go.Figure()  # or any Plotly Express function e.g. px.bar(...)
# fig.add_trace( ... )
# fig.update_layout( ... )

app = dash.Dash()
year_dir = "/home/pi/Aerosol/Data/2022/"

status_files = []

for month in sorted(os.listdir(year_dir)):
    month_dir = year_dir + month + "/"
    for day in sorted(os.listdir(month_dir)):
        day_dir = month_dir + day
        for id in sorted(os.listdir(day_dir)):
            id_dir = day_dir + "/" + id + "/"
            #print(id_dir)
            #print(os.listdir(id_dir))

            try:
                status_file = id_dir + [f for f in os.listdir(id_dir) if "log_" in f][-1]
                with open (status_file, "r") as f:
                    data = json.load(f)
                    status_files.append(data)
            except:
                print("No status file in folder: " + id_dir)

# Filter out only experiments from the last 60 days
status_files = [s for s in status_files if datetime.fromisoformat(s["datetime"]) > datetime.today()-timedelta(days=60) ]

data = []

for js in status_files:
    name = js["id"][0:2]
    try:
        start = datetime.fromisoformat(js["datetime"])
        end = datetime.fromtimestamp(js["log_during"][-1]["epoch"] + js["log_during"][-1]["duration"]*60)
        datum = dict(Task=js["id"], Start=start, Finish=end, Experimentator=name)
        data.append(datum)
    except IndexError as e:
        print(js["id"])
        print(e)
    
#print(data)
df = pd.DataFrame(data)

############## auslastung berechnen ############
eff = {}  
pauses_diff = {}

for experiment in status_files:
    shorty = experiment["id"][0:2]
    eff[shorty] = {
        "hours": [],
        "pauses": []
    }

last_experiment = None
for experiment in status_files:
    print(experiment["id"])

    try:
        start = datetime.fromisoformat(experiment["datetime"])
        end = datetime.fromtimestamp(experiment["log_during"][-1]["epoch"] + experiment["log_during"][-1]["duration"]*60)
        duration = end-start
        hours = duration.total_seconds()/3600
        short_name = experiment["id"][0:2]

        eff[short_name]["hours"].append(hours)
    except IndexError as e:
        print(experiment["id"])
        print(e)

    try:
        if last_experiment["id"][0:2] == short_name:  # selber experimentator
            pause = datetime.fromisoformat(experiment["datetime"]) - datetime.fromisoformat(last_experiment["datetime"])
            pause_hours = pause.total_seconds()/3600
            eff[short_name]["pauses"].append(pause_hours)
        else:
            frome = last_experiment["id"][0:2]
            toe = experiment["id"][0:2]
            pause = datetime.fromisoformat(experiment["datetime"]) - datetime.fromisoformat(last_experiment["datetime"])
            pause_hours = pause.total_seconds()/3600
            try:
                pauses_diff[frome + "->" + toe].append(pause_hours)
            except:
                pauses_diff[frome + "->" + toe] = [pause_hours]
    except:
        pass
    
    last_experiment = experiment


auslastung_stunden = 0
for exp in eff.values():
    for h in exp["hours"]:
        auslastung_stunden += h

print("h: " + str(auslastung_stunden))
percent_auslastung = 100 * auslastung_stunden / 1440
################################################

#################### Pausen ####################
all_pauses = []
for _, dp in pauses_diff.items():
    all_pauses += dp
for _, exp in eff.items():
    all_pauses += exp["pauses"]

all_pauses_fig = px.histogram(all_pauses, nbins=40)
all_pauses_fig.update_layout(
    title="Leerlaufzeiten",
    xaxis_title="Leerlauf in Stunden zwischen zwei aufeinanderfolgenden Experimenten",
    yaxis_title="Häufigkeit des Vorkommens",
    legend_title=""
)
###############################################


fig = px.timeline(df, x_start="Start", x_end="Finish", y="Experimentator", color="Experimentator")


app.layout = html.Div([
    html.H1(children='''
        Laborauslastung der letzten 60 Tage
    '''),

    html.Br(),
    html.H3(children='''
        Tatsächliche Belegung
    '''),
    dcc.Graph(figure=fig),
    html.Br(),
    html.Br(),

    html.H3(children='''
        Statistiken
    '''),
    html.Div(
        children="Auslastung: " + "{:2.2f}% der Zeit ist das Labor belegt".format(percent_auslastung)
    ),
    dcc.Graph(figure=all_pauses_fig)
])

app.run_server(port=8060, debug=False, use_reloader=False)  # Turn off reloader if inside Jupyter
