#!/usr/bin/python3

from abc import abstractmethod
from modbus import Modbus
import psutil
import pathlib
from datalogger import DataLogger, TimingInfo
from RadioController import RadioController
import importlib.util
from adafruit_servokit import ServoKit

# Mocking GPIO lib for development on Mac/Win
try:
    importlib.util.find_spec('RPi.GPIO')
    import RPi.GPIO as GPIO
except ImportError:
    import FakeRPi.GPIO as GPIO

import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta
from setproctitle import setproctitle
sys.path.insert(1, '/home/pi/Aerosol')


# this file contains the description of how to run the experiment
from ablauf import experiment

# Dont allow execution of this file if an experiment is already running
if "AerosolExperiment" in (p.name() for p in psutil.process_iter()):
    print("Ein Experiment laeuft derzeit, deswegen kann keine Aktion ausgefuehrt werden.")
    sys.exit(1)

# Set name of process so it's easier to find with px aux | grep "AerosolExperiment"
setproctitle("AerosolExperiment")

# 1 -> time is measured in seconds, 60 -> minutes
time_multiplier = 60.0

servos = ServoKit(channels=16)

# ####################################### Logging ######################################

date_str = str(datetime.now().strftime("%Y/%m/%d"))

# Status Logger
ttylog = logging.getLogger('ttylog')
ttylog.setLevel(logging.DEBUG)
statusfilename = '/home/pi/Aerosol/Logs/status.log'
ch = logging.FileHandler(statusfilename, "w+")
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(message)s', "%H:%M")
ch.setFormatter(formatter)
ttylog.addHandler(ch)

# Activity Logger
filelog = logging.getLogger('filelog') 
filelog.setLevel(logging.DEBUG)
logfilepath = '/home/pi/Aerosol/Data/' + \
    date_str + '/' + experiment["id"] + "/"
logfilename = '/home/pi/Aerosol/Data/' + date_str + '/' + \
    experiment["id"] + "/log_" + str(datetime.now().strftime("%H-%M")) + '.log'
pathlib.Path(logfilepath).mkdir(parents=True, exist_ok=True)
fh = None
try:
    fh = logging.FileHandler(filename=logfilename)
except PermissionError as e:
    print("-------------------------------------------------------------\n")
    print("ACHTUNG, scheinbar gibt es schon ein Experiment mit dieser ID\n")
    print("-------------------------------------------------------------\n")
    ttylog.warn("-------------------------------------------------------------\n")
    ttylog.warn("ACHTUNG, scheinbar gibt es schon ein Experiment mit dieser ID\n")
    ttylog.warn("-------------------------------------------------------------\n")
    sys.exit(1)

fh.setLevel(logging.DEBUG)
file_formatter = logging.Formatter('%(message)s')
fh.setFormatter(file_formatter)
filelog.addHandler(fh)

# Status Logger 2, logs into the same folder as the data
statusfilename2 = '/home/pi/Aerosol/Data/' + date_str + '/' + \
    experiment["id"] + "/status.log"
ch2 = logging.FileHandler(statusfilename2, "w+")
ch2.setLevel(logging.DEBUG)
ttylog.addHandler(ch2)


# ################################ Experiment control logic ####################################


class ExperimentController:

    # Raspberry Pi GPIO pin numbers
    greenLedPinNr = 18
    redLedPinNr = 23
    radio433_pin_nr = 25
    irPin = 24  # used to control the air conditioning via infrared or the remote

    def __init__(self):

        # Deactivate warning about gpio pins being used
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)

        # set pins to output
        GPIO.setup(self.greenLedPinNr, GPIO.OUT)
        GPIO.setup(self.redLedPinNr, GPIO.OUT)
        GPIO.setup(self.radio433_pin_nr, GPIO.OUT)
        GPIO.setup(self.irPin, GPIO.OUT)

        # start servo with 0% duty cycle, so it doesnt move
        servos.servo[0].set_pulse_width_range(500, 2500)
        servos.servo[0].angle = 180
        self.controller433 = RadioController(self.radio433_pin_nr)


    def setRedLed(self, state: bool):
        '''Turn on the red status led'''

        if state == True:
            GPIO.output(self.redLedPinNr, GPIO.HIGH)
        else:
            GPIO.output(self.redLedPinNr, GPIO.LOW)

    def setGreenLed(self, state: bool):
        '''Turn on the green status led'''
        if state == True:
            GPIO.output(self.greenLedPinNr, GPIO.HIGH)
        else:
            GPIO.output(self.greenLedPinNr, GPIO.LOW)

    def clickButton(self):
        '''Make the servo press the AG button'''
        servos.servo[0].angle = 87.5
        time.sleep(0.5)
        servos.servo[0].angle = 180
        time.sleep(0.5)

    # Experiment execution logic
    def runExperiment(self, experiment):
        self.data_logger = DataLogger(experiment["id"])

        self.setRedLed(True)
        self.setGreenLed(False)

        experiment_log = {}
        experiment_log["id"] = experiment["id"]
        experiment_log["datetime"] = str(datetime.now())
        experiment_log["rounds"] = experiment["repeats"]
        experiment_log["log_pre"] = []
        experiment_log["log_during"] = []
        experiment_log["log_post"] = []

        ttylog.debug("####################### Experiment beginnt #######################\n")

        self.printPlan(experiment)
        self.delayBeforeStart()

        # Begin Experiment Execution
        ttylog.debug("---- Fortschritt ----")
        ttylog.debug("Beginn: " + str(datetime.now()))

        self.data_logger.start_logging_activity()

        # Pre

        for [pre_duration, pre_activity] in experiment["pre"]:
            ttylog.debug("Vorbereitung: " + str(pre_duration) +
                         " min. " + pre_activity + " um " + str(datetime.now()))
            experiment_log["log_pre"].append({"datetime": str(datetime.now(
            )), "epoch": time.time(), "activity": pre_activity, "duration": pre_duration})

            self.data_logger.set_logging_data(TimingInfo(
                current_index=0, comment="pre", round_nr=-1, activity_nr=-1, activity_name=pre_activity, fons=1))

            self.execute_activity(pre_activity, pre_duration)

        # time.sleep(0.1)

        # Protocol
        for round_nr in range(0, experiment["repeats"]):
            ttylog.debug("\n-- Runde " + str(round_nr+1) +
                         " von " + str(experiment["repeats"]) + " --")

            self.data_logger.reset_current_index()

            # Run the protocol
            for activity_nr, (duration, activity, comment) in enumerate(experiment["protocol"]):
                self.data_logger.set_logging_data(TimingInfo(
                    comment=comment, round_nr=round_nr, activity_nr=activity_nr, activity_name=activity, fons=1))

                ttylog.debug("Beginn " + str(duration) + " min. " +
                             activity + " um " + str(datetime.now()))
                experiment_log["log_during"].append({"round": round_nr, "step": activity_nr, "datetime": str(
                    datetime.now()), "epoch": time.time(), "activity": activity, "duration": duration})

                self.execute_activity(activity, duration)


        # time.sleep(0.1)

        # Post
        for [post_duration, post_activity] in experiment["post"]:
            ttylog.debug("Nachbereitung: " + str(post_duration) +
                         " min. " + post_activity + " um " + str(datetime.now()))
            experiment_log["log_post"].append({"datetime": str(datetime.now(
            )), "epoch": time.time(), "activity": post_activity, "duration": post_duration})

            self.data_logger.set_logging_data(TimingInfo(
                current_index=0, comment="post", round_nr=-1, activity_nr=-1, activity_name=post_activity, fons=1))

            self.execute_activity(post_activity, post_duration)

        ttylog.debug("\n####################### Experiment zu Ende #######################")
        filelog.debug(json.dumps(experiment_log, indent=4))

        self.setRedLed(False)
        self.setGreenLed(True)

        self.data_logger.stop_logging_activity()
        self.data_logger.stop_all()

    def runTest(self):
        '''Turn on all equipment for a short time to make sure it works'''
        ttylog.debug("######### Test wird ausgeführt #########")
        ttylog.debug("")

        self.setRedLed(False)
        self.setGreenLed(False)
        ttylog.debug(
            "- Läuft der Raumluftreiniger 10 sek. und geht dann wieder aus?")
        controller.clean_activity(10/60.0)
        ttylog.debug(
            "- Läuft der Aerosolgenerator für 5 sek. und geht dann wieder aus?")
        controller.aerosol_activity(5/60.0)
        controller.ventilator_activity(5/60)
        ttylog.debug(
            "- Blinkt erst die grüne LED 3 sek. und dann die rote 3 sek.?")
        time.sleep(3)

        for x in range(0, 7):
            self.setGreenLed(True)
            time.sleep(0.25)
            self.setGreenLed(False)
            time.sleep(0.25)

        for x in range(0, 7):
            self.setRedLed(True)
            time.sleep(0.25)
            self.setRedLed(False)
            time.sleep(0.25)

        self.setGreenLed(True)
        ttylog.debug("######### Test fertig #########")

    def printPlan(self, experiment):
        '''Print the experiment plan'''

        def log(s):
            ttylog.debug(s)
            print(s)

        # Check legality of all activities
        all_activites = [] + [x[1] for x in experiment["pre"]] + [x[1]
                                                                  for x in experiment["post"]] + [x[1] for x in experiment["protocol"]]
        for activity in all_activites:
            if activity not in ["clean", "pause", "aerosol", "ventilator", "aerosol+ventilator", "clean+ac"]:
                log("###### Illegale Aktion: " +
                      str(activity) + "; Beende Programm ######")
                sys.exit(0)

        log("##### Zeitplan fuer " + experiment["id"] + " #####\n\n")
        experiment_dauer = 0

        # Pre
        for [pre_time, pre_activity] in experiment["pre"]:
            log("Vorher: " + str(pre_time) +
                         " min. -> " + pre_activity)
            experiment_dauer += pre_time

        # protocol
        repeats = experiment["repeats"]
        log("\n-- Wiederholungen: " + str(repeats) + " --")
        for (time, activity, comment) in experiment["protocol"]:
            log(str(time) + " min. -> " +
                         activity + " (" + comment + ")")
            experiment_dauer += time * repeats

        # Post
        for [post_time, post_activity] in experiment["post"]:
            log("\nNachher: " + str(post_time) +
                         " min. -> " + post_activity)
            experiment_dauer += post_time

        log("")
        log("Experiment Dauer: " +
                     str(experiment_dauer/60.0) + " Std.")
        log("Endet am " + str(datetime.now() +
                     timedelta(minutes=experiment_dauer)))
        log("")

    def delayBeforeStart(self):
        '''Do a short countdown before starting the experiment'''

        delay = 5  # seconds
        while delay >= 0:
            startdelay = "Beginn in " + \
                str(delay) + " sek. Zum Abbrechen ctrl+c druecken   "
            ttylog.debug(startdelay)
            delay -= 1
            time.sleep(1)
        ttylog.debug(
            "                                                                               ")

    def execute_activity(self, activity: str, duration: float):
        if activity == "clean":
            self.clean_activity(duration)
        if activity == "pause":
            self.pause_activity(duration)
        if activity == "aerosol":
            self.aerosol_activity(duration)
        if activity == "aerosol+ventilator":
            self.aerosol_and_ventilator_activity(duration)
        if activity == "ventilator":
            self.ventilator_activity(duration)
        if activity == "clean+ac":
            self.clean_and_air_conditioning_activity(duration)

    def clean_activity(self, duration: float):
        # Turn on air purifier
        self.turnOnFilter()
        # Wait
        time.sleep(duration * time_multiplier)
        # Turn off air purifier
        self.turnOffFilter()

    def pause_activity(self, duration: float):
        # Wait
        time.sleep(duration * time_multiplier)

    def aerosol_activity(self, duration: float):
        # Turn on aerosol generator
        self.turnOnAerosol()

        # Wait
        time.sleep(duration * time_multiplier)

        # Turn off aerosol generator
        self.turnOffAerosol()

    def aerosol_and_ventilator_activity(self, duration: float):
        # Turn on aerosol generator
        self.turnOnVentilator()
        self.turnOnAerosol()
        # Wait
        time.sleep(duration * time_multiplier)

        # Turn off aerosol generator
        self.turnOffAerosol()
        self.turnOffVentilator()

    def ventilator_activity(self, duration: float):
        self.turnOnVentilator()
        time.sleep(duration * time_multiplier)
        self.turnOffVentilator()

    def clean_and_air_conditioning_activity(self, duration: float):
        '''Turn on the air purifier and the air condition at the same time
        to cool down the room withouth disturbing air during the experiment.'''
        # Turn on air purifier and AC
        self.turnOnFilter()
        self.toggleAC()
        # Wait
        time.sleep(duration * time_multiplier)
        # Turn off air purifier and AC
        self.toggleAC()
        self.turnOffFilter()

# ################

# socket a1 = air purifier
# socket b1 = aerosol generator
# socket c1 = ventilator

    def turnOnFilter(self):
        '''Turn on the air purifier'''
        self.controller433.turn_on("a1")

    def turnOffFilter(self):
        '''Turn off the air purifier'''
        self.controller433.turn_off("a1")

    def turnOnVentilator(self):
        self.controller433.turn_on("c1")

    def turnOffVentilator(self):
        self.controller433.turn_off("c1")

    def turnOnAerosolSocket(self):
        '''Turn on the 433MHz socket for the aerosol generator'''
        self.controller433.turn_on("b1")

    def turnOffAerosolSocket(self):
        self.controller433.turn_off("b1")

    def turnOnAerosol(self):
        '''Turn on the socket and then click the button to turn on the aerosol generator'''
        self.turnOnAerosolSocket()
        time.sleep(4.0)  # it takes the aerosol generator some time to power on
        self.clickButton()

    def turnOffAerosol(self):
        self.turnOffAerosolSocket()

    def toggleAC(self):
        '''Unfortunately there is no way to explicitly turn it on or off'''
        GPIO.output(self.irPin, GPIO.HIGH)
        time.sleep(0.5)
        GPIO.output(self.irPin, GPIO.LOW)


# ####################################### Executing the experiment #####################################

controller = ExperimentController()

if len(sys.argv) == 1:
    ttylog.debug("Kein Parameter angegeben -> Ende")

elif sys.argv[1] == "print":
    controller.printPlan(experiment)

elif sys.argv[1] == "test":
    controller.runTest()

elif sys.argv[1] == "nothing":
    ttylog.debug("Doing nothing. Ctrl+c to stop")
    while True:
        time.sleep(1)

elif sys.argv[1] == "read":
    print(controller.data_logger.print_header())
    print()
    for d in controller.data_logger.print_data():
        print(d)

elif sys.argv[1] == "toggle":
    if sys.argv[2] == "ac":
        controller.toggleAC()
    else:
        print("Unknown arg: " + sys.argv[2])

elif sys.argv[1] == "turnon":
    if sys.argv[2] == "redled":
        controller.setRedLed(True)
    elif sys.argv[2] == "greenled":
        controller.setGreenLed(True)
    elif sys.argv[2] == "rlr":
        controller.turnOnFilter()
    elif sys.argv[2] == "ag":
        controller.turnOnAerosol()
    elif sys.argv[2] == "fan":
        controller.turnOnVentilator()
    elif sys.argv[2] == "all":
        controller.turnOnAerosolSocket()
        controller.turnOnFilter()
        controller.turnOnVentilator()
    else:
        ttylog.debug("turnon followed by invalid param")

elif sys.argv[1] == "turnoff":
    if sys.argv[2] == "redled":
        controller.setRedLed(False)
    elif sys.argv[2] == "greenled":
        controller.setGreenLed(False)
    elif sys.argv[2] == "rlr":
        controller.turnOffFilter()
    elif sys.argv[2] == "ag":
        controller.turnOffAerosol()
    elif sys.argv[2] == "fan":
        controller.turnOffVentilator()
    elif sys.argv[2] == "all":
        controller.turnOffAerosolSocket()
        controller.turnOffFilter()
        controller.turnOffVentilator()
        controller.setGreenLed(False)
        controller.setRedLed(False)
    else:
        ttylog.debug("turnoff followed by invalid param")

# passing 'run' actually starts the experiment
elif sys.argv[1] == "run":
    controller.runExperiment(experiment)

else:
    ttylog.debug("Kein valider Parameter angegeben -> Ende")


# Remove empty log file if nothing is logged
logging.shutdown()

if os.path.getsize(logfilename) == 0:
    os.remove(logfilename)

if os.path.getsize(statusfilename2) == 0 or sys.argv[1] != "run":
    os.remove(statusfilename2)

if len(os.listdir(logfilepath)) == 0:
    os.rmdir(logfilepath)

expdatepath = '/home/pi/Aerosol/Data/' + date_str + '/'
if len(os.listdir(expdatepath)) == 0:
    os.rmdir(expdatepath)
