const express = require('express')
const app = express()
const port = 4000
const util = require('util');
const exec = util.promisify(require('child_process').exec);

var cors = require('cors')
app.use(cors())

async function expCmd(cmd) {
  try {
      const { stdout, stderr } = await exec('/home/pi/Aerosol/Code/experiment.py ' + cmd)
      console.log('stdout:', stdout)
      console.log('stderr:', stderr)
      return stdout
  } catch (err) {
     console.error(err)
  }
}

async function cmd(cmd) {
  try {
      const { stdout, stderr } = await exec(cmd)
      console.log('stdout:', stdout)
      console.log('stderr:', stderr)
      return stdout
  } catch (err) {
     console.error(err)
  }
}



app.get('/clean1', (req, res) => {
	expCmd('turnon rlr').then(r => res.send(r))
  console.log("executed cmd clean1")
})

app.get('/clean0', (req, res) => {
  expCmd('turnoff rlr').then(r => res.send(r))
  console.log("executed cmd clean0")
})

app.get('/aerosol1', (req, res) => {
  expCmd('turnon ag').then(r => res.send(r))
  console.log("executed cmd aerosol1")
})

app.get('/aerosol0', (req, res) => {
  expCmd('turnoff ag').then(r => res.send(r))
  console.log("executed cmd aerosol0")
})

app.get('/experimentStart', (req, res) => {
  expCmd('run').then(r => res.send(r))
  console.log("executed cmd experimentStart")
})

app.get('/experimentKill', (req, res) => {
  cmd('/home/pi/Aerosol/Code/killExperiment.sh').then(r => res.send(r))
  console.log("executed cmd experimentKill")
})

app.get('/test', (req, res) => {
  expCmd('test').then(r => res.send(r))
  console.log("executed cmd test")
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})