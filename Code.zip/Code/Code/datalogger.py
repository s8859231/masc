from __future__ import annotations
import logging
import multiprocessing
from multiprocessing.queues import Queue
import os
from datetime import datetime
from pathlib import Path
from time import sleep, time
from numpy import min
from modbus import Modbus
from typing import List
from dataclasses import dataclass


@dataclass
class TimingInfo:
    '''This class is used to store information about the current state of the experiment'''

    current_index: int = -1        # the index/number of the measurement in the *current* round
    comment: str = "<None>"        # typically used to store the name of the current activity in a round
    round_nr: int = -1             # which round the experiment is currently in
    activity_nr: int = -1          # the index/number of the current activity in the *current* round
    activity_name: str = "<None>"  # the name of the current activity (e.g. 'aerosol')
    fons: int = -1                 # 'First of new section', is 1 if the activity just changed

    def list(self) -> List[str]:
        '''Create a list of str with all the info of this class.
        This is needed for an easy way to log this info into a csv'''
      
        return [str(self.current_index), str(self.comment), str(self.round_nr),
                str(self.activity_nr), str(self.activity_name), str(self.fons)]

    def merge(self, other: TimingInfo):
        '''other overrides self, if the fields are not the default values'''
        return TimingInfo(
            current_index=other.current_index if other.current_index != -1 else self.current_index,
            comment=other.comment if other.comment != "<None>" else self.comment,
            round_nr=other.round_nr if other.round_nr != -1 else self.round_nr,
            activity_nr=other.activity_nr if other.activity_nr != -1 else self.activity_nr,
            activity_name=other.activity_name if other.activity_name != "<None>" else self.activity_name,
            fons=other.fons if other.fons != -1 else self.fons,
        )

class DataLogger:
    '''This class spawns async processes to log 11D data into csv files
    every n seconds'''

    data_file_names = [] # gets filled by setup()

    # Device names and their corresponding IPs
    ips = [
        ("11D-0", "10.25.168.210"),
        ("11D-1", "10.25.168.213"),
        ("11D-2", "10.25.168.207"),  # "10.25.168.207"),
        ("11D-3", "10.25.168.192")]

    mbs = []  # contains the modbus connections
    for name, ip in ips:
        try:
            mb = Modbus(ip)
            mb.get_interval()  # this is just a check if the connection works
            mbs.append((name, mb))
        except:  # connection failed, so we just don't use this device
            pass

    def __init__(self, experiment_id: str) -> None:
        self.experiment_id = experiment_id
        self.loggers = []

        # fastest interval of all devices is used
        self.interval = min([mb.get_interval() for _, mb in self.mbs])

        self.q = multiprocessing.Queue()  # is used to send TimingInfo data to the logging process
        self.reset_ci_q = multiprocessing.Queue()  # is used to signal to the logging process, that the current index should be set to 0
        self.log_proc: multiprocessing.Process = None  # the logging process
        self.setup()
        self.log_header()

    def start_logging_activity(self):
        self.log_proc = multiprocessing.Process(target=self._log_activity, args=(self.q, self.reset_ci_q))
        self.log_proc.start()

    def set_logging_data(self, timing_info: TimingInfo):
        self.q.put([timing_info])

    def reset_current_index(self) -> None:
        self.reset_ci_q.put([0])

    def stop_logging_activity(self):
        self.log_proc.terminate()

    def stop_all(self):
        logging.shutdown()

        # calculate the means to create smaller files for easier usage
        for filename in self.data_file_names:
            os.system('python3 /home/pi/Aerosol/Code/convert.py ' + filename + ' PM2.5')

        for filename in self.data_file_names:
            os.system('python3 /home/pi/Aerosol/Code/convert.py ' + filename  + ' total_count')

        # Save the files from being manipulated
        os.system('sudo chattr +i -R ' + self.log_folder)

    # runs in its own process
    def _log_activity(self, q: Queue, reset_ci_q: Queue):
        _timing_info = TimingInfo()
        starttime = time()
        while True:

            if not q.empty():
                changed_numbers: TimingInfo = q.get()[0]
                _timing_info = _timing_info.merge(changed_numbers)
            
            if not reset_ci_q.empty():
                _ = reset_ci_q.get()
                _timing_info.current_index = 0
                starttime = time()

            # TODO: make this run in parallel, not sequentially
            for i in range(0, len(self.mbs)):
                data = ",".join(self.mbs[i][1].get_data_row_string() + _timing_info.list() + [str(time() - starttime)])
                self.loggers[i].info(data)

            _timing_info.current_index += 1
            _timing_info.fons = 0

            sleep(self.interval - ((time() - starttime) % self.interval))

    # def ___set_timing_(self, ci, sn, rn, anr, ana):
    #     # self.current_index = ci
    #     # self.stage_name = sn
    #     # self.round_nr = rn
    #     # self.activity_nr = anr
    #     # self.activity_name = ana
    #     self.q.put([ci, sn, rn, anr, ana])

    def _startLogging(self):
        self.setup()
        self.log_header()

        self.q = multiprocessing.Queue()
        self.log_proc = multiprocessing.Process(target=self.continuously_log_data, args=(self.q,))
        self.log_proc.start()

    def _stopLogging(self):
        self.log_proc.terminate()
        logging.shutdown()

    def setup(self):
        # create log file folder for date, if it doesnt exits
        date_str = str(datetime.now().strftime("%Y/%m/%d"))
        self.log_folder = "/home/pi/Aerosol/Data/" + date_str + "/" + self.experiment_id
        Path(self.log_folder).mkdir(parents=True, exist_ok=True)

        # create data loggers
        file_formatter = logging.Formatter('%(message)s')
        for name, mb in self.mbs:
            filelog = logging.getLogger('datalog_' + name)
            filelog.setLevel(logging.DEBUG)
            fh_filename = '/home/pi/Aerosol/Data/' + date_str + '/' + self.experiment_id + '/data_' + str(datetime.now().strftime("%H-%M")) + "_" + name + '.csv'
            fh = logging.FileHandler(filename=fh_filename)
            fh.setFormatter(file_formatter)
            filelog.addHandler(fh)    
            self.loggers.append(filelog)
            self.data_file_names.append(fh_filename)

    def log_header(self):
        timing = ["current_index", "stage_name", "round_nr", "activity_nr", "activity_name", "fons", "elapsed_time_s"]

        # log header row
        for i in range(0, len(self.mbs)):
            header = ",".join(self.mbs[i][1].get_header_row() + timing)
            self.loggers[i].info(header)  

    def print_header(self) -> str:
        timing = ["current_index", "stage_name", "round_nr", "activity_nr", "activity_name", "fons", "elapsed_time_s"]
        header = ",".join(self.mbs[0][1].get_header_row() + timing)
        return header

    def print_data(self) -> List[str]:
        return [mb[1].get_data_row() for mb in self.mbs]

    # ATTENTION: this runs in its own process
    # def ___continuously_log_data_(self, q:Queue):

    #     timing_numbers = [-1, "None", -1, -1, "None"]
    #     # continuously log data
    #     while True: 
    #         # TODO: make this run in parallel, not sequentially
    #         for i in range(0, len(self.mbs)):
                
    #             # get the timing info
    #             if not q.empty():
    #                 old_current_index = timing_numbers[0]
    #                 timing_numbers = q.get() #[self.current_index, self.stage_name, self.round_nr, self.activity_nr, self.activity_name]
    #                 if timing_numbers[0] == -3:
    #                     timing_numbers[0] = old_current_index
    #             timing = [str(x) for x in timing_numbers]

    #             data = ",".join(self.mbs[i][1].get_data_row_string() + timing)
    #             self.loggers[i].info(data)

    #         timing_numbers[0] += 1

    #         sleep(self.interval)
