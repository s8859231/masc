# -*- coding: utf-8 -*-

# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.

import pandas
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd
from dash.dependencies import Input, Output
import plotly.graph_objects as go
from setproctitle import setproctitle
import os

setproctitle("AerosolDashboard")



external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

# assume you have a "long-form" data frame
# see https://plotly.com/python/px-arguments/ for more options
df = pd.DataFrame(columns=["time", "total_count"])

fig = px.line(df, x="time", y="total_count")

app.layout = html.Div(children=[
    #html.H1(children='Hello Dash'),

    html.Div(["Parameter: ", dcc.Input(id='my-input', value='total_count', type='text')]),
    html.Br(),
    html.Div(id='my-output'),
    dcc.Interval(
        id='interval-component',
        interval=120*1000, # in milliseconds
        n_intervals=0
    ),
])

@app.callback(
    Output(component_id='my-output', component_property='children'),
    Input(component_id='my-input', component_property='value'),
    Input('interval-component', 'n_intervals')
)
def update_output_div(input_value, n_intervals):

    updatemenus = [
            dict(
                 buttons=[
                     dict(label="Linear",  
                          method="relayout", 
                          args=[{"yaxis.type": "linear"}]),
                     dict(label="Log", 
                          method="relayout", 
                          args=[{"yaxis.type": "log"}]),
                                  ])]
                                  

    data_dir = '/home/pi/Aerosol/Data/'

    def get_latest_dir_in(path):
        all_subdirs = [path + d for d in os.listdir(path) if os.path.isdir(path + d)]
        latest_subdir = max(all_subdirs, key=os.path.getmtime)
        return latest_subdir

    def get_last_of_sorted_dirs(path):
        subdirs = [path + x + "/" for x in os.listdir(path)]
        subdirs.sort()
        return subdirs[-1]

    latest_date_dir = get_last_of_sorted_dirs(data_dir)
    latest_date_dir = get_last_of_sorted_dirs(latest_date_dir)
    latest_date_dir = get_last_of_sorted_dirs(latest_date_dir)

    print("#############################")
    print(latest_date_dir)
    print("#############################")

    latest_id_dir = get_latest_dir_in(latest_date_dir)

    print(latest_id_dir)
    print()

    csv_files = [latest_id_dir + "/" + c for c in os.listdir(latest_id_dir) if ".csv" in c]

    print(csv_files)
    print()
    
    total_fig = go.Figure()
    total_fig.update_layout(updatemenus=updatemenus, title_text="Particles per liter")

    average_fig = go.Figure()
    average_fig.update_layout(title_text="Überlagerung aller Runden")

    mean_fig = go.Figure()
    mean_fig.update_layout(title_text="Mittelwerte aller Runden ('during' Phase)")
    
    temperature_fig = go.Figure()
    temperature_fig.update_layout(title_text='Raumtemperatur')

    motor_fig = go.Figure()
    motor_fig.update_layout(title_text="Motorstrom")

    for csv in csv_files:
        df = pd.read_csv(csv)
        df_only_exp = df[(df.stage_name != "pre") & (df.stage_name != "post")]
        mean_df = df[df.stage_name == "during"].groupby(["current_index"]).median()

        total_fig.add_trace(go.Scatter(x=df["time"], y=df[input_value], name=csv[-9:-4], mode='lines'))
        total_fig.update_yaxes(type='log')
        total_fig.update_yaxes(type='linear')

        if (df["external_temperature"] > 0.1).any():
            temperature_fig.add_trace(go.Scatter(x=df["time"], y=df["external_temperature"], name=csv[-9:-4], mode='lines'))

        motor_fig.add_trace(go.Scatter(x=df["time"], y=df["motor_current"], name=csv[-9:-4], mode='lines'))

        average_fig.add_trace(go.Scatter(x=df_only_exp["elapsed_time_s"], y=df_only_exp[input_value], name=csv[-9:-4], mode='lines', line=dict(width=1.0)))

        mean_fig.add_trace(go.Scatter(x=mean_df["elapsed_time_s"], y=mean_df[input_value], name=csv[-9:-4], mode='lines'))

    # show where new phases begin
    # news = pd.read_csv(csv_files[0])
    # news = news[news.fons == 1]
    # for index, row in news.iterrows():
    #     lineloc = row["epoch"]*1000
    #     total_fig.add_vline(x=lineloc, annotation_text=row["activity_name"])



    hist_fig = px.bar(df.loc[:, "0.25":"35.15"].mean())
    hist_fig.update_layout(title_text="Größenverteilung")


    lines = open("/home/pi/Aerosol/Logs/status.log", "r").readlines()
    status_str = "\n".join(lines)

    return html.Div(children=[
        html.Div(
            children="Experiment folder: " + latest_id_dir
        ),
        dcc.Graph(
            id='example-graph',
            figure=total_fig
        ), 
        dcc.Graph(
            id='example-graph',
            figure=average_fig
        ), 
        dcc.Graph(
            id='example-graph',
            figure=mean_fig
        ), 
        dcc.Graph(
            id='example-graph',
            figure=hist_fig
        ),
        dcc.Graph(
            id='example-graph',
            figure=temperature_fig
        ),
        dcc.Graph(
            id='example-graph',
            figure=motor_fig
        ),
        html.Pre(
            children=status_str
        )
    ])

if __name__ == '__main__':
    app.run_server(debug=False, host='0.0.0.0', port = 8090)
