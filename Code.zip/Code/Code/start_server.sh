#!/usr/bin/bash
cd server
npm run start &
cd ..
cd webinterface
npm run start &
echo "Backend und Frontend fuer die Bedienung ueber die Webseite gestartet"