#!/usr/bin/bash

echo "Das Experiment wird jetzt abgebrochen und die Geraete ausgeschaltet..."

pkill -f "AerosolExperiment"
sleep 1
pkill -f "DataLogger"
sleep 1

/home/pi/Aerosol/Code/experiment.py turnoff all

echo "#### EXPERIMENT WURDE ABGEBROCHEN ####"