# versuche 433 mhz fernbedienung signale vom rpi zu senden

import RPi.GPIO as GPIO
import time
import csv

class RadioController:

    REPEATS = 1

    # the codes, read from file in init
    PLAYBACK = {
        "a1on": [],
        "b1on": [],
        "c1on": [],
        "a1off": [],
        "b1off": [],
        "c1off": [],
    }

    def __init__(self, pin_nr: int):
        self.send_pin_433_nr = pin_nr

        ### Read file to play back ###
        for filename in self.PLAYBACK.keys():
            with open("/home/pi/Aerosol/Code/remote_socket_codes/" + filename, 'r') as csvfile:
                rage = csv.reader(csvfile)
                lastTime = 0
                last_val = False
                cur_val = False
                for row in rage:
                    rowtime = float(row[0])
                    row[0] = rowtime - lastTime
                    lastTime = rowtime
                    row[1] = float(row[1]) > 0.5
                    cur_val = row[1]

                    # correct for Pi's timing errors
                    if cur_val == False and last_val == False: # falling edge
                        row[0] = row[0] - 0.0001
                    if cur_val == True and last_val == True:
                        row[0] = row[0] - 0.0002
                    if row[0] < 0:
                        row[0] = 0

                    self.PLAYBACK[filename].append(row)
                    last_val = cur_val

    def turn_on(self, socket: str):
        self.switch_socket(str(socket) + "on")
        time.sleep(0.1)

    def turn_off(self, socket: str):
        self.switch_socket(str(socket) + "off")
        time.sleep(0.1)

    def switch_socket(self, FILE):
        PLAYBACK_SIZE = len(self.PLAYBACK[FILE]);

        ### Playback of signal ###
        for r in range(self.REPEATS):
            for i in range(PLAYBACK_SIZE):
                GPIO.output(self.send_pin_433_nr, self.PLAYBACK[FILE][i][1])
                time.sleep(self.PLAYBACK[FILE][i][0])